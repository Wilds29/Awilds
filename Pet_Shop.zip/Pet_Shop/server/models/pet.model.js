const mongoose = require("mongoose")

const PetSchema = new mongoose.Schema({
    name: {
        type: String,
        required: [true, "PET NAME IS REQUIRED"],
        minlength: [3, "Name must be 3 characters long!"],
    },
    type: {
        type: String,
        required: [true, "PET TYPE IS REQUIRED"]
    },
    description: {
        type: String,
        required: [true, "DESCRIPTION IS REQUIRED"],
        minlength: [3, "Name must be 3 characters long!"],
    },
    skill1: {
        type: String,
        required: [false],
        minlength: [3, "Skill must be 3 characters long"],
    },
    skill2: {
        type: String,
        required: [false],
        minlength: [3, "Skill must be 3 characters long"],
    },
    skill3: {
        type: String,
        required: [false],
        minlength: [3, "Skill must be 3 characters long"],
    }
}, {timestamps: true})

module.exports.Pets = mongoose.model("Pets", PetSchema);
