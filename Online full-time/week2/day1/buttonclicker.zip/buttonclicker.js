function logout(element){
    element.innerText = "logout";
}

function remove(element){
    element.remove();
}