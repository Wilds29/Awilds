console.log("hello")

function addlike(count){
    var count = document.querySelector('#count');

    count.innerHTML = parseInt(count.innerHTML) + 1;
}

function addlike2(count){
    var count = document.querySelector('#count2');

    count.innerHTML = parseInt(count.innerHTML) + 1;
}

function addlike3(element){
    var element = document.querySelector('#count3');

    element.innerHTML = parseInt(element.innerHTML) + 1;
}