import React from "react";

function Error() {
    return (
        <div>
            <h3>These are not the droids you're looking for.</h3>
            <img src="https://i.redd.it/87j9joumswd71.jpg" alt="CP3-NoMo" />
        </div>
    )
}


export default Error;