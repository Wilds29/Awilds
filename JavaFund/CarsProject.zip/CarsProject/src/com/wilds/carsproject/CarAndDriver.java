package com.wilds.carsproject;

public class CarAndDriver {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Driver driver = new Driver();

        driver.drive();
        driver.drive();
        driver.drive();
        driver.drive();

        driver.boost();

        driver.refuel();
        driver.refuel();
        driver.refuel();
    }
}
