package com.wilds.omikujiform.controllers;

import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;


@Controller
public class HomeController {

	@GetMapping("/home")
	public String setCount(HttpSession Session, Model model) {
		if(Session.getAttribute("count") == null) {
		Session.setAttribute("count", 0);
		}
		int tempCount = (int)Session.getAttribute("count");
		tempCount++;
		Session.setAttribute("count", tempCount);
		return "counterPage.jsp";
	}
	
	@GetMapping("/get/count")
	public String getCount() {
		return "countGet.jsp";
	}
}
