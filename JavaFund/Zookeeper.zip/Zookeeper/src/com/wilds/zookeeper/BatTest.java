package com.wilds.zookeeper;

public class BatTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Bat dracula = new Bat(300);
		dracula.fly();
		dracula.displayEnergyLevel();
		dracula.attackTown();
		dracula.displayEnergyLevel();
		dracula.eatHumans();
		dracula.eatHumans();
		dracula.displayEnergyLevel();
		dracula.fly();
		dracula.displayEnergyLevel();
		dracula.attackTown();
		dracula.displayEnergyLevel();
		dracula.eatHumans();
		dracula.eatHumans();
		dracula.displayEnergyLevel();
		dracula.attackTown();
		dracula.displayEnergyLevel();
	}

}
