package com.wilds.studentroster;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StudentRosterApplicationTests {

	@Test
	void contextLoads() {
	}

}
