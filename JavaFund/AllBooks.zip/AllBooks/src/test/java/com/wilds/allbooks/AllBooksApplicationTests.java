package com.wilds.allbooks;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AllBooksApplicationTests {

	@Test
	void contextLoads() {
	}

}
