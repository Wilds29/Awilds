package com.wilds.allbooks;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AllBooksApplication {

	public static void main(String[] args) {
		SpringApplication.run(AllBooksApplication.class, args);
	}

}
