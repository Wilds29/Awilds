// given a name, will say "good day" to that person by name.


	function greetsomeone(person){
    if (person == "anakin"){
        console.log("good day, anakin");
    }
    if(person == "dooku"){
        console.log("I'm coming for you, Dooku!", "6:30pm 9/1/22");
    }
}
greetsomeone("anakin");
greetsomeone("dooku");