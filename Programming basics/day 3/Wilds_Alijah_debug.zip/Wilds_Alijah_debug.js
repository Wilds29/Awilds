function greeting(){
    var word
    return greeting;
    }
    var word = greeting;
    console.log ("hello world");