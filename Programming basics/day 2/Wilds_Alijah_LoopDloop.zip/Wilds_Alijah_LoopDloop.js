// start of the loop is 2 miles
// piece of candy every time a runner reaches 2 miles 
// but stops giving candy out at mile 6.


for (var miles = 2; miles <=6; miles += 2 ){
    console.log("miles", miles)
    var candy = 1
    if (miles % 2 === 0)
    console.log ("candy", candy)
}